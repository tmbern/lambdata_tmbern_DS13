# import pandas as pd
# import numpy

# df = pd.DataFrame({'x': [1, 2, 3, 4, 5,np.nan],
#  'y': [np.nan,np.nan , 1, 2, 3, 4 ],
#  'z': [1, 2, 3, 4, 5, 6]})


# from lambdata_tmbern_DS13.my_mod import check_for_nulls


# import pandas
# from my_lambdata_tmbern_Unit3.class2 import convert_names

# print("hello world")

# df3= pandas.DataFrame({'abbrev': ['UT', 'WA', 'CA', 'CO']})
# full_df3 = convert_names(df3)
# print(full_df3.head())