# lambdata_tmbern_DS13
# my-lambdata


## Installation

```
pip install https://test.pypi.org/project/my-lambdata-tmbern-Unit3/1.0.2/ 
```

## Usage

Check for nulls and split date columns into month day year



