import pandas as pd
import numpy

df = pd.DataFrame({'x': [1, 2, 3, 4, 5,np.nan],
 'y': [np.nan,np.nan , 1, 2, 3, 4 ],
 'z': [1, 2, 3, 4, 5, 6]})


from lambdata_tmbern_DS13.my_mod import check_for_nulls