# lambdata_tmbern_DS13
# my-lambdata


## Installation

```sh
pip install https://test.pypi.org/project/my-lambdata-tmbern-Unit3/1.0/ 
```

## Usage

Check for nulls and split date columns into month day year



